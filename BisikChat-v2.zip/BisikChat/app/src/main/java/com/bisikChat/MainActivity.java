package com.bisikChat;

import android.Manifest;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothService bluetoothService;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> messages = new ArrayList<>();

    private EditText inputMessage;
    private RecyclerView recyclerView;
    private Button btnSend, btnConnect, btnDiscover;
    private TextView statusText, tvSelfAvatar, tvSelfName, tvSelfStatus;

    private UserSession session;
    private String connectedDevice = null;
    private static final int REQUEST_PERMISSIONS = 1;
    private static final int REQUEST_ENABLE_BT = 2;

    private Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case BluetoothService.MESSAGE_READ:
                    byte[] buf = (byte[]) msg.obj;
                    String text = new String(buf, 0, msg.arg1);
                    // format: "NAME|MESSAGE"
                    String senderName = "Tamu";
                    String msgText = text;
                    if (text.contains("|")) {
                        senderName = text.substring(0, text.indexOf("|"));
                        msgText = text.substring(text.indexOf("|") + 1);
                    }
                    addMessage(msgText, false, senderName);
                    break;
                case BluetoothService.MESSAGE_CONNECTED:
                    connectedDevice = (String) msg.obj;
                    statusText.setText("🟢 " + connectedDevice);
                    btnConnect.setText("Putuskan");
                    addSystemMessage("Terhubung dengan " + connectedDevice);
                    break;
                case BluetoothService.MESSAGE_DISCONNECTED:
                    connectedDevice = null;
                    statusText.setText("🔴 Tidak terhubung");
                    btnConnect.setText("Hubungkan");
                    addSystemMessage("Koneksi terputus");
                    break;
                case BluetoothService.MESSAGE_ERROR:
                    Toast.makeText(MainActivity.this, "Error: " + msg.obj, Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        session = new UserSession(this);
        if (!session.isLoggedIn()) {
            startActivity(new Intent(this, RegisterActivity.class));
            finish(); return;
        }

        setContentView(R.layout.activity_main);
        initViews();
        initBluetooth();
        requestPermissions();
    }

    private void initViews() {
        inputMessage  = findViewById(R.id.inputMessage);
        recyclerView  = findViewById(R.id.recyclerView);
        btnSend       = findViewById(R.id.btnSend);
        btnConnect    = findViewById(R.id.btnConnect);
        btnDiscover   = findViewById(R.id.btnDiscover);
        statusText    = findViewById(R.id.statusText);
        tvSelfAvatar  = findViewById(R.id.tvSelfAvatar);
        tvSelfName    = findViewById(R.id.tvSelfName);
        tvSelfStatus  = findViewById(R.id.tvSelfStatus);

        // Set user identity di header
        tvSelfName.setText(session.getName());
        tvSelfStatus.setText(session.getStatus());
        tvSelfAvatar.setText(session.getAvatar());
        GradientDrawable bg = (GradientDrawable) tvSelfAvatar.getBackground().mutate();
        bg.setColor(session.getColor());

        chatAdapter = new ChatAdapter(messages);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(chatAdapter);

        btnSend.setOnClickListener(v -> sendMessage());
        btnConnect.setOnClickListener(v -> showDeviceList());
        btnDiscover.setOnClickListener(v -> makeDiscoverable());

        // Long press avatar → logout
        tvSelfAvatar.setOnLongClickListener(v -> {
            showProfileMenu(); return true;
        });

        inputMessage.setOnEditorActionListener((v, id, e) -> { sendMessage(); return true; });
    }

    private void initBluetooth() {
        BluetoothManager btm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = btm.getAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth tidak tersedia", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        bluetoothService = new BluetoothService(handler);
        if (!bluetoothAdapter.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);
        } else {
            bluetoothService.startServer();
        }
    }

    private void requestPermissions() {
        String[] perms = {
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.ACCESS_FINE_LOCATION
        };
        List<String> needed = new ArrayList<>();
        for (String p : perms)
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                needed.add(p);
        if (!needed.isEmpty())
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), REQUEST_PERMISSIONS);
    }

    private void sendMessage() {
        String text = inputMessage.getText().toString().trim();
        if (text.isEmpty()) return;
        if (connectedDevice == null) {
            Toast.makeText(this, "Belum terhubung ke perangkat lain", Toast.LENGTH_SHORT).show();
            return;
        }
        // Kirim format: "NAMA|PESAN" agar penerima tahu siapa pengirimnya
        String payload = session.getName() + "|" + text;
        bluetoothService.write(payload.getBytes());
        addMessage(text, true, session.getName());
        inputMessage.setText("");
    }

    private void addMessage(String text, boolean isMine, String sender) {
        messages.add(new ChatMessage(text, isMine, System.currentTimeMillis(), sender));
        chatAdapter.notifyItemInserted(messages.size() - 1);
        recyclerView.scrollToPosition(messages.size() - 1);
    }

    private void addSystemMessage(String text) {
        messages.add(new ChatMessage(text, false, System.currentTimeMillis(), null, true));
        chatAdapter.notifyItemInserted(messages.size() - 1);
        recyclerView.scrollToPosition(messages.size() - 1);
    }

    private void showDeviceList() {
        if (connectedDevice != null) { bluetoothService.disconnect(); return; }
        Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
        if (paired.isEmpty()) {
            Toast.makeText(this, "Tidak ada perangkat. Pair dulu via Settings.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[paired.size()];
        BluetoothDevice[] devs = new BluetoothDevice[paired.size()];
        int i = 0;
        for (BluetoothDevice d : paired) { names[i] = d.getName() + "\n" + d.getAddress(); devs[i] = d; i++; }
        new AlertDialog.Builder(this)
            .setTitle("Pilih Perangkat")
            .setItems(names, (dlg, w) -> {
                bluetoothService.connect(devs[w]);
                statusText.setText("⏳ Menghubungkan ke " + devs[w].getName() + "...");
            }).show();
    }

    private void makeDiscoverable() {
        Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivityForResult(i, 3);
        bluetoothService.startServer();
        addSystemMessage("Menunggu koneksi masuk...");
    }

    private void showProfileMenu() {
        String[] opts = {"Lihat Profil", "Edit Status", "Logout"};
        new AlertDialog.Builder(this)
            .setTitle(session.getName())
            .setItems(opts, (dlg, w) -> {
                if (w == 0) showProfile();
                else if (w == 1) editStatus();
                else confirmLogout();
            }).show();
    }

    private void showProfile() {
        new AlertDialog.Builder(this)
            .setTitle("Profil Saya")
            .setMessage("Nama: " + session.getName() + "\nStatus: " + session.getStatus()
                      + "\nAlias Device: " + session.getDeviceAlias()
                      + "\n\n(Data tersimpan lokal, tidak di cloud)")
            .setPositiveButton("OK", null)
            .show();
    }

    private void editStatus() {
        EditText et = new EditText(this);
        et.setHint("Status baru...");
        et.setText(session.getStatus());
        new AlertDialog.Builder(this)
            .setTitle("Edit Status")
            .setView(et)
            .setPositiveButton("Simpan", (d, w) -> {
                session.updateStatus(et.getText().toString().trim());
                tvSelfStatus.setText(session.getStatus());
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
            .setTitle("Logout?")
            .setMessage("Profil lokal akan dihapus dari perangkat ini.")
            .setPositiveButton("Logout", (d, w) -> {
                session.logout();
                startActivity(new Intent(this, RegisterActivity.class));
                finish();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bluetoothService != null) bluetoothService.stop();
    }
}
